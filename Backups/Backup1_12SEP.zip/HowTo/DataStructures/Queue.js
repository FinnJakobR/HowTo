"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnqueueInQueue = exports.DequeueVideoQueue = exports.EnqueueVideoQueue = exports.DequeueApiQueue = exports.EnqueueApiQueue = exports.DequeueAIQueue = exports.isEmpty = exports.CreateQueues = void 0;
class Queue {
    constructor() {
        this.size = 0;
        this.items = [];
        console.log("INIT NEW QUEUE");
    }
    enqueue(item) {
        this.items.push(item);
        console.log(this.items);
        this.size++;
    }
    isEmpty() {
        if (this.size === 0)
            return true;
        return false;
    }
    dequeue() {
        console.log(this.items);
        var element;
        if (this.isEmpty())
            throw new Error("Could not dequeue... Queue is Empty");
        else {
            element = this.items[0];
            this.items.removeAtIndex(0);
            return element;
        }
    }
    print() {
        for (let index = 0; index < this.items.length; index++) {
            console.log("Value at Index: " + index + " .... " + this.items[index]);
        }
    }
}
var AI_QUEUE = new Queue();
var API_QUEUE = new Queue();
var VIDEO_QUEUE = new Queue();
function CreateApiQueue() {
    API_QUEUE = new Queue();
}
function CreateAIQueue() {
    AI_QUEUE = new Queue();
}
function CreateVideoQueue() {
    VIDEO_QUEUE = new Queue();
}
function CreateQueues() {
    CreateApiQueue();
    CreateAIQueue();
    CreateVideoQueue();
}
exports.CreateQueues = CreateQueues;
function isEmpty() {
    return API_QUEUE.isEmpty();
}
exports.isEmpty = isEmpty;
function DequeueAIQueue() {
    const DequedElement = AI_QUEUE.dequeue();
    return DequedElement;
}
exports.DequeueAIQueue = DequeueAIQueue;
function EnqueueApiQueue(element) {
    API_QUEUE.enqueue(element);
}
exports.EnqueueApiQueue = EnqueueApiQueue;
function DequeueApiQueue() {
    const DequedElement = API_QUEUE.dequeue();
    return DequedElement;
}
exports.DequeueApiQueue = DequeueApiQueue;
function EnqueueVideoQueue(element) {
    if (!element.URL)
        throw Error("URL is not defined");
    VIDEO_QUEUE.enqueue(element);
    return;
}
exports.EnqueueVideoQueue = EnqueueVideoQueue;
function DequeueVideoQueue() {
    const DequedElement = VIDEO_QUEUE.dequeue();
    return DequedElement;
}
exports.DequeueVideoQueue = DequeueVideoQueue;
function EnqueueInQueue(element) {
    AI_QUEUE.enqueue(element);
    return;
}
exports.EnqueueInQueue = EnqueueInQueue;
