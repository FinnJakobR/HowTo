"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetGeneratedPrompt = exports.savePromptsInFile = exports.saveFilePromps = exports.SaveInDict = void 0;
const FileOP_1 = require("../FileOperations/FileOP");
var Dictonary = {};
async function ReadPrompsTXT() {
    const Promps = await (0, FileOP_1.ReadPromptFile)("../Promps.txt");
    return Promps;
}
function SaveInDict(prompt, generatedPrompt) {
    Dictonary[prompt] = generatedPrompt;
    return;
}
exports.SaveInDict = SaveInDict;
async function saveFilePromps() {
    const data = await ReadPrompsTXT();
    if (data.length > 0) {
        Dictonary = JSON.parse(data);
    }
    return;
}
exports.saveFilePromps = saveFilePromps;
async function savePromptsInFile() {
    console.log("SAVE PROMPS In FILE");
    const StringLDict = JSON.stringify(Dictonary);
    await (0, FileOP_1.saveInFile)(StringLDict);
}
exports.savePromptsInFile = savePromptsInFile;
function GetGeneratedPrompt(prompt) {
    const GeneratedPromp = Dictonary[prompt];
    return GeneratedPromp;
}
exports.GetGeneratedPrompt = GetGeneratedPrompt;
