"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetStream = exports.AddFileStream = exports.GETUserData = exports.RemoveUser = exports.IsUserConnected = exports.AddVideoToUser = exports.ADD_User = exports.isAllreadyRequested = exports.GetIndexLength = exports.ChangeTimeStamp = void 0;
const fs_1 = __importDefault(require("fs"));
const Settings_1 = require("../Settings/Settings");
const USERS = {};
function ChangeTimeStamp(_id, newTimeStamp) {
    USERS[_id].NextTimeStampsMs += newTimeStamp;
    USERS[_id].VideoIndexLengths[USERS[_id].videos] = newTimeStamp;
    return;
}
exports.ChangeTimeStamp = ChangeTimeStamp;
function GetIndexLength(_id, index) {
    return USERS[_id].VideoIndexLengths[index];
}
exports.GetIndexLength = GetIndexLength;
function isAllreadyRequested(_id, FileName) {
    if (USERS[_id].RequestedFiles[FileName])
        return true;
    return false;
}
exports.isAllreadyRequested = isAllreadyRequested;
function ADD_User(_id) {
    USERS[_id] = {
        _id: _id,
        videos: 0,
        NextTimeStampsMs: 0,
        StreamFileStream: null,
        VideoIndexLengths: {},
        RequestedFiles: {}
    };
    return;
}
exports.ADD_User = ADD_User;
function AddVideoToUser(_id) {
    USERS[_id].videos = USERS[_id].videos + 1;
    return;
}
exports.AddVideoToUser = AddVideoToUser;
function IsUserConnected(_id) {
    if (USERS[_id])
        return true;
    else
        return false;
}
exports.IsUserConnected = IsUserConnected;
function RemoveUser(_id) {
    USERS[_id]?.StreamFileStream?.destroy();
    USERS[_id] = null;
    return;
}
exports.RemoveUser = RemoveUser;
function GETUserData(_id) {
    return USERS[_id];
}
exports.GETUserData = GETUserData;
function AddFileStream(_id) {
    USERS[_id].StreamFileStream = fs_1.default.createWriteStream(`../${Settings_1.GeneralSettings.VideoDirName}/${_id}/index.m3u8`, { flags: 'a' });
}
exports.AddFileStream = AddFileStream;
function GetStream(_id) {
    return USERS[_id].StreamFileStream;
}
exports.GetStream = GetStream;
