"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const worker_threads_1 = require("worker_threads");
const Api_1 = require("../Api/Api");
const Queue_1 = require("../DataStructures/Queue");
const UserDictonary_1 = require("../DataStructures/UserDictonary");
async function Search() {
    const Data = (0, Queue_1.DequeueApiQueue)();
    const UserData = (0, UserDictonary_1.GETUserData)(Data._ID);
    if (Data._ID != UserData.id)
        throw new Error("Queue id is not equal to UserDataBase id");
    if (!(0, UserDictonary_1.IsUserConnected)(Data._ID) && !worker_threads_1.isMainThread) {
        worker_threads_1.parentPort?.postMessage({ _id: Data._ID, detail: "User is Disconnected" });
        return;
    }
    ;
    const SearchResponse = await (0, Api_1.SearchVideo)(Data.QUESTION);
    const VIDEO_Queue_Element = { _ID: Data._ID, URL: SearchResponse.URL, QUESTION: Data.QUESTION };
    (0, Queue_1.EnqueueVideoQueue)(VIDEO_Queue_Element);
    (0, UserDictonary_1.ChangeTimeStamp)(UserData._id, SearchResponse.DURATION);
    if (!worker_threads_1.isMainThread) {
        worker_threads_1.parentPort?.postMessage({ _ID: Data._ID, QUESTION: Data.QUESTION, URL: Data.URL, TIMESTAMP: SearchResponse.DURATION, detail: "API Worker Ended" });
    }
    return;
}
Search();
