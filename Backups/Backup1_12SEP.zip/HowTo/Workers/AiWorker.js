"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const worker_threads_1 = require("worker_threads");
const OpenAi_1 = require("../AI/OpenAi");
const Queue_1 = require("../DataStructures/Queue");
const UserDictonary_1 = require("../DataStructures/UserDictonary");
async function CreateNewQuestion() {
    const Data = (0, Queue_1.DequeueAIQueue)();
    if (!(0, UserDictonary_1.IsUserConnected)(Data._ID) && !worker_threads_1.isMainThread) {
        worker_threads_1.parentPort?.postMessage({ _id: Data._ID, detail: "User is disconnected" });
        return;
    }
    ;
    const newQuestion = await (0, OpenAi_1.GenerateNewWord)(Data.QUESTION);
    const API_Queue_Element = { _ID: Data._ID, URL: null, QUESTION: newQuestion };
    if (!worker_threads_1.isMainThread) {
        worker_threads_1.parentPort?.postMessage({ _ID: Data._ID, newQuestion: newQuestion, detail: "AI_WORKER_ENDED" });
    }
    (0, Queue_1.EnqueueApiQueue)(API_Queue_Element);
    return;
}
CreateNewQuestion();
