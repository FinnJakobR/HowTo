"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Queue_1 = require("../DataStructures/Queue");
const UserDictonary_1 = require("../DataStructures/UserDictonary");
const FileOP_1 = require("../FileOperations/FileOP");
const Download_1 = require("../VideoOps/Download");
const worker_threads_1 = require("worker_threads");
async function Download_ConvertVideo() {
    const QueueData = (0, Queue_1.DequeueVideoQueue)();
    const UserData = (0, UserDictonary_1.GETUserData)(QueueData._ID);
    const Videos = UserData.videos;
    if (QueueData._ID != UserData._id)
        throw Error("Queue ID is not Equal User ID");
    if (!(0, UserDictonary_1.IsUserConnected)(UserData._id) && worker_threads_1.isMainThread) {
        worker_threads_1.parentPort?.postMessage({ _id: UserData._id, detail: "User is disconnected" });
        return;
    }
    await (0, FileOP_1.CreateVideoOrdner)(Videos, QueueData._ID);
    await (0, Download_1.DownloadAndConvertVideo)(QueueData.URL, QueueData._ID, UserData.videos);
    (0, UserDictonary_1.AddVideoToUser)(QueueData._ID);
    return;
}
Download_ConvertVideo();
