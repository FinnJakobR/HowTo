"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DictonarySettings = exports.StreamServerStettings = exports.SocketServerSettings = exports.OpenAiSettings = exports.GeneralSettings = exports.ApiSettings = void 0;
exports.ApiSettings = {
    page: 1,
    safeSearch: true,
    type: "Video",
    resolution: "HD",
    sortBy: "Relevance",
    limit: 2
};
exports.GeneralSettings = {
    VideoDirName: "Videos",
    HostName: "http://localhost"
};
exports.OpenAiSettings = {
    apikey: "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",
    model: "davinci:ft-universit-t-der-k-nste-berlin-2022-02-12-18-36-05",
    NumPerRun: 3,
    delayMs: 1000,
};
exports.SocketServerSettings = {
    port: 3000,
    NewVideoCommand: "NEW_VIDEO",
    SendTimeStampsCommand: "NEW_TIMESTAMP",
    StartClientPlayerCommand: "START_PLAYER",
    CheckQuestCommand: "CHECK_QUESTION"
};
exports.StreamServerStettings = {
    port: 5000,
    url: "/:id/:video/:file"
};
exports.DictonarySettings = {
    promptPath: "./Promps.txt"
};
