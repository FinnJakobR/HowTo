
export const ApiSettings: API_SETTINGS_TYPE = {
    page: 1,
    safeSearch: true,
    type: "Video" ,
    resolution: "HD" ,
    sortBy: "Relevance",
    limit: 2
}

export const GeneralSettings = {
  VideoDirName: "Videos",
  HostName: "http://localhost"
}


export const OpenAiSettings = {
    apikey : "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" ,
    model: "davinci:ft-universit-t-der-k-nste-berlin-2022-02-12-18-36-05",
    NumPerRun: 3,
    delayMs: 1000,
}

export const SocketServerSettings = {
  port: 3000,
  NewVideoCommand: "NEW_VIDEO",
  SendTimeStampsCommand: "NEW_TIMESTAMP",
  StartClientPlayerCommand: "START_PLAYER",
  CheckQuestCommand: "CHECK_QUESTION"
}

export const StreamServerStettings = {
  port: 5000,
  url: "/:id/:video/:file"
}



export const DictonarySettings = {
  promptPath: "./Promps.txt"
}