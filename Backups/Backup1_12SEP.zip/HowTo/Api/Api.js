"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchVideo = void 0;
const ytsr_1 = require("ytsr");
const ytsr_2 = __importDefault(require("ytsr"));
const Settings_1 = require("../Settings/Settings");
const Options = {
    safeSearch: Settings_1.ApiSettings.safeSearch,
    pages: Settings_1.ApiSettings.page,
    limit: Settings_1.ApiSettings.limit,
};
async function SearchVideo(request) {
    const Filter = await CreateFilters(request);
    const response = await (0, ytsr_2.default)(Filter, Options);
    const DurationInString = response.items[0].type == "video" ? response.items[0].duration : console.log("This Result Item is not a Video");
    const DurationinMs = ConvertDuration(DurationInString);
    const VideoUrl = response.items[0].type == "video" ? response.items[0].url : console.log("This Result Item is not a Video");
    const ReturnData = {
        ID: response.items[0].type == "video" ? response.items[0].id : console.log("This Result Item is not a Video"),
        NAME: response.items[0].type == "video" ? response.items[0].title : console.log("This Result Item is not a Video"),
        DURATION: DurationinMs,
        URL: VideoUrl
    };
    return ReturnData;
}
exports.SearchVideo = SearchVideo;
async function CreateFilters(request) {
    const filters1 = await (0, ytsr_1.getFilters)(request);
    const filter1 = filters1.get('Type').get(Settings_1.ApiSettings.type);
    const filters2 = await ytsr_2.default.getFilters(filter1.url);
    const filter2 = filters2.get('Features').get(Settings_1.ApiSettings.resolution);
    if (Settings_1.ApiSettings.sortBy != "Relevance") {
        const filters3 = await ytsr_2.default.getFilters(filter2.url);
        const filter3 = filters3.get("Sort by").get(Settings_1.ApiSettings.sortBy);
        return filter3.url;
    }
    return filter2.url;
}
function getSeconds(_string) {
    if (!_string.includes(":"))
        throw new Error("The String does not match the accepted the Pattern EX: 3:33");
    const Index = _string.indexOf(":");
    const Seconds = Number(_string.slice(Index + 1));
    return Seconds;
}
function getMinutes(_string) {
    if (!_string.includes(":"))
        throw new Error("The String does not match the accepted the Pattern EX: 3:33");
    const Index = _string.indexOf(":");
    const Minutes = Number(_string.slice(0, Index));
    return Minutes * 60;
}
function ConvertDuration(DurationInString) {
    return (getSeconds(DurationInString) + getMinutes(DurationInString)) * 1000;
}
