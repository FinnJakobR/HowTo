"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadAndConvertVideo = void 0;
const ytdl_core_1 = __importDefault(require("ytdl-core"));
const child_process_1 = __importDefault(require("child_process"));
const ffmpeg_static_1 = __importDefault(require("ffmpeg-static"));
const worker_threads_1 = require("worker_threads");
const Settings_1 = require("../Settings/Settings");
const FileOP_1 = require("../FileOperations/FileOP");
const UserDictonary_1 = require("../DataStructures/UserDictonary");
async function DownloadAndConvertVideo(url, _id, videoNum) {
    //TODO: Ordner erstellen welche Video 1 2 usw 
    var isFirstTsFile = true;
    await new Promise((resolve, reject) => {
        const tracker = {
            start: Date.now(),
            audio: { downloaded: 0, total: Infinity },
            video: { downloaded: 0, total: Infinity },
            merged: { frame: 0, speed: '0x', fps: 0 },
        };
        const audio = (0, ytdl_core_1.default)(url, { quality: 'highestaudio' })
            .on('progress', (_, downloaded, total) => {
            tracker.audio = { downloaded, total };
        });
        const video = (0, ytdl_core_1.default)(url, { quality: 'highestvideo' })
            .on('progress', (_, downloaded, total) => {
            tracker.video = { downloaded, total };
        });
        //../${GeneralSettings.VideoDirName}/${_id}/${_id}.mp4
        const ConvertProcess = child_process_1.default.spawn(ffmpeg_static_1.default, [
            '-loglevel', '8', '-hide_banner',
            '-i', 'pipe:4',
            '-i', 'pipe:5',
            '-map', '0:a',
            '-map', '1:v',
            '-c:v', 'copy',
            "-f", "avi",
            "pipe:3"
        ], {
            windowsHide: true,
            stdio: [
                /* Standard: stdin, stdout, stderr */
                'inherit', 'inherit', 'inherit',
                /* Custom: pipe:3, pipe:4, pipe:5 */
                'pipe', 'pipe', 'pipe'
            ],
        });
        ConvertProcess.on("spawn", () => {
            console.log("Start Download");
        });
        ConvertProcess.on("end", () => {
            console.log("a Video is sucessfull downloaded");
        });
        //ConvertProcess.stdio[3]?.pipe(process.stdio[0]);
        audio.pipe(ConvertProcess.stdio[4]);
        video.pipe(ConvertProcess.stdio[5]);
        const HLSProcess = child_process_1.default.spawn(ffmpeg_static_1.default, [
            '-loglevel', '8', '-hide_banner',
            "-i", "pipe:3",
            "-progress", "pipe:4",
            "-start_number", "0",
            "-g", "1",
            "-hls_time", "1",
            "-hls_list_size", "0",
            "-level", "6.0",
            "-crf", "28",
            "-hls_segment_filename", `../${Settings_1.GeneralSettings.VideoDirName}/${_id}/${videoNum}/%d.ts`,
            `../${Settings_1.GeneralSettings.VideoDirName}/${_id}/buffer.m3u8` //TODO: CHANGE 
        ], {
            windowsHide: true,
            stdio: [
                /* Standard: stdin, stdout, stderr */
                'inherit', 'inherit', 'inherit',
                /* Custom: pipe:3, pipe:4*/
                'pipe', "pipe"
            ],
        });
        ConvertProcess.stdio[3]?.pipe(HLSProcess.stdio[3]);
        HLSProcess.stdio[4]?.on("data", () => {
            if (isFirstTsFile) {
                isFirstTsFile = false;
                setTimeout(() => {
                    worker_threads_1.parentPort?.postMessage({ _id: _id, detail: "First Segments are loaded" });
                }, 1000);
            }
            if (!(0, UserDictonary_1.IsUserConnected)(_id) && !worker_threads_1.isMainThread) {
                try {
                    HLSProcess.stdio[3].destroy();
                    HLSProcess.kill();
                    ConvertProcess.kill();
                }
                catch (error) {
                    console.log("KILLED CONVERT");
                }
            }
            ;
        });
        HLSProcess.on("close", async () => {
            if (!worker_threads_1.isMainThread && (0, UserDictonary_1.IsUserConnected)(_id)) {
                console.log("end");
                worker_threads_1.parentPort?.postMessage({ _id: _id, detail: "DownLoadingConverting Finish" });
            }
            else {
                console.log("KILLED PROCESS");
                worker_threads_1.parentPort?.postMessage({ _id: _id, detail: "User is disconnected" });
            }
            await (0, FileOP_1.RemoveFile)(`../${Settings_1.GeneralSettings.VideoDirName}/${_id}/buffer.m3u8`);
            resolve();
        });
    });
}
exports.DownloadAndConvertVideo = DownloadAndConvertVideo;
