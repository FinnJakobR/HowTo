"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const UserDictonary_1 = require("../DataStructures/UserDictonary");
const FileOP_1 = require("../FileOperations/FileOP");
const Settings_1 = require("../Settings/Settings");
const StreamServer = (0, express_1.default)();
const PORT = Settings_1.StreamServerStettings.port;
StreamServer.get(Settings_1.StreamServerStettings.url, async (req, res) => {
    const _id = req.params.id;
    const videos = req.params.video;
    const FileName = req.params.file;
    if (FileName == "index.m3u8")
        return res.status(200).sendFile(`../${Settings_1.GeneralSettings.VideoDirName}/${_id}/index.m3u8`);
    const isAllreadySended = (0, UserDictonary_1.isAllreadyRequested)(_id, `${videos}/${FileName}`);
    if (isAllreadySended)
        return res.status(200).sendFile(`../${Settings_1.GeneralSettings.VideoDirName}/${_id}/${videos}/${FileName}`);
    const FileNumber = FileName.match(/\d+/g);
    const IndexLength = (0, UserDictonary_1.GetIndexLength)(_id, Number(videos));
    if (Number(FileNumber[0]) == IndexLength) {
        await (0, FileOP_1.WriteInStreamFile)(`#EXT-X-DISCONTINUITY\n#EXTINF:1.000000\n${Settings_1.GeneralSettings.HostName}/${_id}/${videos + 1}/0.ts`, _id);
        return res.status(200).sendFile(`../${Settings_1.GeneralSettings.VideoDirName}/${_id}/${videos}/${FileName}`);
    }
    await (0, FileOP_1.WriteInStreamFile)(`#EXTINF:1.000000\n${Settings_1.GeneralSettings.HostName}/${_id}/${videos}/${FileNumber[0] + 1}.ts`, _id);
    return res.status(200).sendFile(`../${Settings_1.GeneralSettings.VideoDirName}/${_id}/${videos}/${FileName}`);
});
StreamServer.listen(PORT, () => {
    console.log("STREAM SERVER STARTED");
});
