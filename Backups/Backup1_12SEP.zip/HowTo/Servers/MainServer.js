"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Settings_1 = require("../Settings/Settings");
const express_1 = __importDefault(require("express"));
const http_1 = __importDefault(require("http"));
const socket_io_1 = require("socket.io");
const UserDictonary_1 = require("../DataStructures/UserDictonary");
const FileOP_1 = require("../FileOperations/FileOP");
const worker_threads_1 = require("worker_threads");
const Queue_1 = require("../DataStructures/Queue");
const Dictonary_1 = require("../DataStructures/Dictonary");
const PORT = Settings_1.SocketServerSettings.port;
const ExpressMiddleware = (0, express_1.default)();
const server = http_1.default.createServer(ExpressMiddleware);
const SocketServer = new socket_io_1.Server(server);
ExpressMiddleware.get("/", (req, res) => {
    res.send("HELLO WORLD");
});
SocketServer.on("connection", async (socket) => {
    console.log("A new User is Connected");
    (0, UserDictonary_1.ADD_User)(socket.id);
    (0, FileOP_1.CreateUserDir)(socket.id);
    (0, FileOP_1.CreateStreamingFile)(socket.id);
    if (!worker_threads_1.isMainThread)
        throw new Error("MainServer File have to on MainThread!");
    socket.on(Settings_1.SocketServerSettings.NewVideoCommand, (arg) => {
        const QueueItem = { _ID: socket.id, URL: null, QUESTION: arg.value };
        (0, Queue_1.EnqueueApiQueue)(QueueItem);
        const Api = new worker_threads_1.Worker("../Workers/ApiWorker.js");
        Api.on("message", (message) => {
            SocketServer.to(message._id).emit(Settings_1.SocketServerSettings.SendTimeStampsCommand, { question: arg.value, TimeStamp: message.TimeStamp });
            const Download = new worker_threads_1.Worker("../Workers/DownloadWorker.js");
            Download.on("message", (message) => {
                if (message.detail == "First Segments are loaded" && arg.isFirstVideo) {
                    SocketServer.to(message._id).emit(Settings_1.SocketServerSettings.StartClientPlayerCommand);
                }
                if (message.detail == "User is disconnected") {
                    (0, FileOP_1.DeleteUserDir)(message._id);
                    console.log("User " + message._id + " is Discconected!");
                    return;
                }
                if (message.detail == "DownLoadingConverting Finish") {
                    const AI = new worker_threads_1.Worker("../Workers/AiWorker.js");
                    AI.on("message", (message) => {
                        SocketServer.to(message._id).emit(Settings_1.SocketServerSettings.CheckQuestCommand, { Question: message.newQuestion, BeforeQuestion: arg.value });
                        return;
                    });
                }
                ;
            });
        });
    });
});
SocketServer.on("disconnect", (socket) => {
    (0, UserDictonary_1.RemoveUser)(socket.id);
});
server.listen(PORT, async () => {
    console.log("Pogramm sucessfull Started");
    console.log("Server Listen on port %d", PORT);
    await (0, Dictonary_1.saveFilePromps)();
});
