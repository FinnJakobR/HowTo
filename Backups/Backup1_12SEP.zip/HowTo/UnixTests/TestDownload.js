"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Download_1 = require("../VideoOps/Download");
function TestDownload() {
    (0, Download_1.DownloadAndConvertVideo)("https://www.youtube.com/watch?v=cpIwMZ3cUEc", "Finn", 0);
    return;
}
TestDownload();
