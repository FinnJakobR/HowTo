"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const stream_1 = require("stream");
const stream = fs_1.default.createWriteStream("./Test.txt", { flags: 'a' });
async function WriteInFile(data) {
    await new Promise((resolve, reject) => {
        const ReadStream = stream_1.Readable.from(`${data}\n`);
        ReadStream.pipe(stream, { end: false });
        ReadStream.on("close", () => {
            resolve();
        });
    });
}
setInterval(async () => {
    await WriteInFile("HALLO");
}, 1000);
