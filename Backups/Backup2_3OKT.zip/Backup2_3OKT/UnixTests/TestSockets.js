"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const socket_io_client_1 = require("socket.io-client");
const Settings_1 = require("../Settings/Settings");
const connection = (0, socket_io_client_1.io)("http://localhost:3000");
const Question = "How to play uno";
connection.on("connect_error", (err) => {
    console.log(err);
    //throw new Error("COULD NOT CONNECT TO SERVER!");
});
const args = { isFirstVideo: true, value: Question };
connection.on("connect", () => {
    console.log(connection.id);
    connection.emit(Settings_1.SocketServerSettings.NewVideoCommand, args);
});
connection.on(Settings_1.SocketServerSettings.SendTimeStampsCommand, (args) => {
    console.log("TIMESTAMP: " + args.TimeStamp);
});
connection.on(Settings_1.SocketServerSettings.StartClientPlayerCommand, (args) => {
    console.log("START PLAYER");
});
connection.on(Settings_1.SocketServerSettings.CheckQuestCommand, (args) => {
    console.log(args.Question);
    connection.emit(Settings_1.SocketServerSettings.NewVideoCommand, { isFirstVideo: false, value: args.Question });
});
