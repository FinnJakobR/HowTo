"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Api_1 = require("../Api/Api");
async function TestApi(request) {
    const response = await (0, Api_1.SearchVideo)(request);
    console.log(response);
}
TestApi("How to play uno?");
