"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DataApi_1 = require("../Api/DataApi");
async function POST(id) {
    await (0, DataApi_1.EnqueueOpApi)("dsiuhfsuhfsf", { _ID: "dsiuhfsuhfsf", URL: null, QUESTION: "WAS GEHT" });
    const Data = await (0, DataApi_1.DequeueOpApi)("api");
    console.log(Data);
}
;
POST("UU");
