"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const OpenAi_1 = require("../AI/OpenAi");
const Api_1 = require("../Api/Api");
async function StartDebug() {
    console.log("Start Debug....");
    console.log("First Test the Api Response.... Test for How to play football");
    const response = await (0, Api_1.SearchVideo)("How to play Football?");
    console.log("The Response is: " + response);
    console.log("Now Check the AI with the Same Input as the Api Test...");
    const Ai_response = await (0, OpenAi_1.GenerateNewWord)("How to play football");
    console.log("The Response of the AI is " + Ai_response);
    return;
}
