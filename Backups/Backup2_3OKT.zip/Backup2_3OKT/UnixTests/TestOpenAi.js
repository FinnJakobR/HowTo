"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const OpenAi_1 = require("../AI/OpenAi");
const TestPromps = ["How to p"];
async function TestOpenAi(prompt) {
    console.log("RUN");
    const data = await (0, OpenAi_1.GenerateNewWord)(prompt);
    console.log(data);
}
for (let index = 0; index < 1; index++) {
    TestOpenAi("How to play piano");
}
