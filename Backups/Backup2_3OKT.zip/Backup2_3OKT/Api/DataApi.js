"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetFileStreamApi = exports.AddFileStreamApi = exports.GetUserDataApi = exports.RemoveUserApi = exports.IsUserConnectedApi = exports.IsAllreadyRequestedApi = exports.addVideoToUserApi = exports.AddUserApi = exports.GetIndexLengthApi = exports.ChangeTimeStampApi = exports.DeleteUserFromQueueApi = exports.GetPromptApi = exports.SavePromptApi = exports.EnqueueOpApi = exports.DequeueOpApi = void 0;
const axios_1 = __importDefault(require("axios"));
const Settings_1 = require("../Settings/Settings");
const ServerPort = Settings_1.DataBaseServerSettings.port;
const ServerHostName = Settings_1.DataBaseServerSettings.hostname;
const Main_Url = ServerHostName + ":" + ServerPort + "/";
async function DequeueOpApi(type) {
    const res = await axios_1.default.get(Main_Url + "QUEUE/" + type.toUpperCase() + "/DEQUEUE");
    return res.data.DATA;
}
exports.DequeueOpApi = DequeueOpApi;
async function EnqueueOpApi(type, Data) {
    const data = await axios_1.default.post(Main_Url + "QUEUE/" + type.toUpperCase() + "/ENQUEUE", Data);
    return;
}
exports.EnqueueOpApi = EnqueueOpApi;
async function SavePromptApi(prompt, generatedPrompt) {
    const Body = {
        prompt: prompt,
        generatedPrompt: generatedPrompt
    };
    await axios_1.default.post(Main_Url + "DICTONARY/" + "SAVEPROMPT", Body);
    return;
}
exports.SavePromptApi = SavePromptApi;
async function GetPromptApi(prompt) {
    const Body = {
        prompt: prompt
    };
    const res = await axios_1.default.post(Main_Url + "DICTONARY/" + "GETPROMPT", Body);
    return res.data.prompt;
}
exports.GetPromptApi = GetPromptApi;
async function DeleteUserFromQueueApi(_id) {
    const res = await axios_1.default.get(Main_Url + "QUEUE/" + _id + "/DELETE_USER");
    return;
}
exports.DeleteUserFromQueueApi = DeleteUserFromQueueApi;
async function ChangeTimeStampApi(_id, newTimeStamp) {
    const Body = {
        newTimeStamp: newTimeStamp
    };
    await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/changetimestamp", Body);
    return;
}
exports.ChangeTimeStampApi = ChangeTimeStampApi;
async function GetIndexLengthApi(_id, index) {
    const Body = {
        index: index
    };
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/GETINDEXLENGTH", Body);
    return res.data.DATA;
}
exports.GetIndexLengthApi = GetIndexLengthApi;
async function AddUserApi(_id) {
    const Body = {};
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/addUser", Body);
    return;
}
exports.AddUserApi = AddUserApi;
async function addVideoToUserApi(_id) {
    const Body = {};
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/AddVideoToUser", Body);
    return;
}
exports.addVideoToUserApi = addVideoToUserApi;
async function IsAllreadyRequestedApi(_id, FileName) {
    const Body = {
        FileName: FileName
    };
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/IsAllreadyRequested", Body);
    return res.data.ISREQ;
}
exports.IsAllreadyRequestedApi = IsAllreadyRequestedApi;
async function IsUserConnectedApi(_id) {
    const Body = {};
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/isuserconnected", Body);
    return res.data.ISUSERCON;
}
exports.IsUserConnectedApi = IsUserConnectedApi;
async function RemoveUserApi(_id) {
    const Body = {};
    await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/RemoveUser", Body);
    return;
}
exports.RemoveUserApi = RemoveUserApi;
async function GetUserDataApi(_id) {
    const Body = {};
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/GetUserData", Body);
    return res.data.DATA;
}
exports.GetUserDataApi = GetUserDataApi;
async function AddFileStreamApi(_id) {
    const Body = {};
    await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/AddFileStream", Body);
    return;
}
exports.AddFileStreamApi = AddFileStreamApi;
async function GetFileStreamApi(_id) {
    const Body = {};
    const res = await axios_1.default.post(Main_Url + "USERDATABASE/" + _id + "/getstream", Body);
    return res.data.STREAM;
}
exports.GetFileStreamApi = GetFileStreamApi;
