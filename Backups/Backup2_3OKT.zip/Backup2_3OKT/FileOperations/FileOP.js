"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WriteInStreamFile = exports.CreateStreamingFile = exports.CreateVideoOrdner = exports.CreateUserDir = exports.DeleteUserDir = exports.RemoveFile = exports.saveInFile = exports.ReadPromptFile = void 0;
const promises_1 = __importDefault(require("fs/promises"));
const DataApi_1 = require("../Api/DataApi");
const Settings_1 = require("../Settings/Settings");
/**
  * Read The File of the Prompt
  * @param path define the Path of the Prompt File
  * @returns the Promps in the File from given Path
  */
async function ReadPromptFile(path) {
    const ReadedData = await promises_1.default.readFile(path, "utf-8");
    return ReadedData;
}
exports.ReadPromptFile = ReadPromptFile;
async function saveInFile(data) {
    await promises_1.default.writeFile(Settings_1.DictonarySettings.promptPath, data, "utf-8");
    return;
}
exports.saveInFile = saveInFile;
async function RemoveFile(path) {
    await promises_1.default.unlink(path);
    return;
}
exports.RemoveFile = RemoveFile;
async function DeleteUserDir(_id) {
    await promises_1.default.rm(`${Settings_1.GeneralSettings.path}/${Settings_1.GeneralSettings.VideoDirName}/${_id}`, { recursive: true });
    return;
}
exports.DeleteUserDir = DeleteUserDir;
async function CreateUserDir(_id) {
    await promises_1.default.mkdir(`${Settings_1.GeneralSettings.path}/${Settings_1.GeneralSettings.VideoDirName}/${_id}`);
    return;
}
exports.CreateUserDir = CreateUserDir;
async function CreateVideoOrdner(video, _id) {
    await promises_1.default.mkdir(`${Settings_1.GeneralSettings.path}/${Settings_1.GeneralSettings.VideoDirName}/${_id}/${video}`);
    return;
}
exports.CreateVideoOrdner = CreateVideoOrdner;
async function CreateStreamingFile(_id) {
    const FileData = `#EXTM3U
#EXT-X-PLAYLIST-TYPE:EVENT
#EXT-X-VERSION:7
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:1
#EXT-X-DISCONTINUITY-SEQUENCE:0
#EXTINF:1.00000
${Settings_1.GeneralSettings.HostName}:${Settings_1.StreamServerStettings.port}/${_id}/0/0.ts
`;
    await promises_1.default.writeFile(`${Settings_1.GeneralSettings.path}/${Settings_1.GeneralSettings.VideoDirName}/${_id}/index.m3u8`, FileData);
    await (0, DataApi_1.AddFileStreamApi)(_id);
    return;
}
exports.CreateStreamingFile = CreateStreamingFile;
async function WriteInStreamFile(data, _id) {
    console.log(data);
    await promises_1.default.writeFile(`${Settings_1.GeneralSettings.VideoDirName}/${_id}/index.m3u8`, data, { flag: "a" });
    return;
}
exports.WriteInStreamFile = WriteInStreamFile;
