"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnqueueInQueue = exports.DequeueVideoQueue = exports.EnqueueVideoQueue = exports.DequeueApiQueue = exports.DeleteUserFromQueue = exports.EnqueueApiQueue = exports.DequeueAIQueue = exports.CreateQueues = void 0;
class Queue {
    constructor() {
        this.size = 0;
        this.items = [];
        console.log("INIT NEW QUEUE");
    }
    enqueue(item) {
        this.items.push(item);
        console.log("ENQUEUE: ");
        console.log(this.items.length);
        console.log(item);
        this.size++;
    }
    isEmpty() {
        if (this.size === 0)
            return true;
        return false;
    }
    dequeue() {
        var element;
        if (this.isEmpty())
            throw new Error("Could not dequeue... Queue is Empty");
        else {
            element = this.items[0];
            this.items.splice(0, 1);
            console.log("DEQUEUE: " + this.items.length);
            return element;
        }
    }
    //TODO: Add to API
    DeleteUserFromQueue(_id) {
        for (let index = 0; index < this.items.length; index++) {
            if (this.items[index]._ID == _id) {
                this.items.removeAtIndex(index);
            }
        }
        return;
    }
    print() {
        for (let index = 0; index < this.items.length; index++) {
            console.log("Value at Index: " + index + " .... " + this.items[index]);
        }
    }
}
var AI_QUEUE = new Queue();
var API_QUEUE = new Queue();
var VIDEO_QUEUE = new Queue();
function CreateApiQueue() {
    API_QUEUE = new Queue();
}
function CreateAIQueue() {
    AI_QUEUE = new Queue();
}
function CreateVideoQueue() {
    VIDEO_QUEUE = new Queue();
}
function CreateQueues() {
    CreateApiQueue();
    CreateAIQueue();
    CreateVideoQueue();
}
exports.CreateQueues = CreateQueues;
function isEmpty() {
    return API_QUEUE.isEmpty();
}
function DequeueAIQueue() {
    const DequedElement = AI_QUEUE.dequeue();
    return DequedElement;
}
exports.DequeueAIQueue = DequeueAIQueue;
function EnqueueApiQueue(element) {
    API_QUEUE.enqueue(element);
}
exports.EnqueueApiQueue = EnqueueApiQueue;
function DeleteUserFromQueue(_id) {
    API_QUEUE.DeleteUserFromQueue(_id);
    AI_QUEUE.DeleteUserFromQueue(_id);
    VIDEO_QUEUE.DeleteUserFromQueue(_id);
    return;
}
exports.DeleteUserFromQueue = DeleteUserFromQueue;
function DequeueApiQueue() {
    const DequedElement = API_QUEUE.dequeue();
    return DequedElement;
}
exports.DequeueApiQueue = DequeueApiQueue;
function EnqueueVideoQueue(element) {
    if (!element.URL)
        throw Error("URL is not defined");
    VIDEO_QUEUE.enqueue(element);
    return;
}
exports.EnqueueVideoQueue = EnqueueVideoQueue;
function DequeueVideoQueue() {
    const DequedElement = VIDEO_QUEUE.dequeue();
    return DequedElement;
}
exports.DequeueVideoQueue = DequeueVideoQueue;
function EnqueueInQueue(element) {
    AI_QUEUE.enqueue(element);
    return;
}
exports.EnqueueInQueue = EnqueueInQueue;
