"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const FileOP_1 = require("../FileOperations/FileOP");
const Download_1 = require("../VideoOps/Download");
const DataApi_1 = require("../Api/DataApi");
async function Download_ConvertVideo() {
    const QueueData = await (0, DataApi_1.DequeueOpApi)("video");
    const UserData = await (0, DataApi_1.GetUserDataApi)(QueueData._ID);
    console.log(UserData);
    const Videos = UserData.videos;
    if (QueueData._ID != UserData._id)
        throw Error("Queue ID is not Equal User ID");
    const isConnected = await (0, DataApi_1.IsUserConnectedApi)(UserData._id);
    if (!isConnected) {
        process.send({ _id: UserData._id, detail: "User is disconnected" });
        return;
    }
    await (0, FileOP_1.CreateVideoOrdner)(Videos, QueueData._ID);
    await (0, Download_1.DownloadAndConvertVideo)(QueueData.URL, QueueData._ID, UserData.videos);
    await (0, DataApi_1.addVideoToUserApi)(QueueData._ID);
    return;
}
Download_ConvertVideo();
