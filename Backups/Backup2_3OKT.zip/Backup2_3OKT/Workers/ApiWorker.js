"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Api_1 = require("../Api/Api");
const DataApi_1 = require("../Api/DataApi");
async function Search() {
    const Data = await (0, DataApi_1.DequeueOpApi)("api");
    const UserData = await (0, DataApi_1.GetUserDataApi)(Data._ID);
    console.log(UserData);
    if (Data._ID != UserData._id)
        throw new Error("Queue id is not equal to UserDataBase id");
    const isConnected = await (0, DataApi_1.IsUserConnectedApi)(Data._ID);
    if (!isConnected) {
        process.send({ MESSAGE: "USER IS DISCONNECTED!", DATA: null });
        return;
    }
    const SearchResponse = await (0, Api_1.SearchVideo)(Data.QUESTION);
    console.log("RES: " + SearchResponse);
    const VIDEO_Queue_Element = { _ID: Data._ID, URL: SearchResponse.URL, QUESTION: Data.QUESTION };
    await (0, DataApi_1.EnqueueOpApi)("video", VIDEO_Queue_Element);
    console.log("DURATION: " + SearchResponse.DURATION);
    console.log("ID: " + UserData._id);
    await (0, DataApi_1.ChangeTimeStampApi)(UserData._id, SearchResponse.DURATION);
    process.send({ "MESSAGE": "OPERATION SUCESS!", "DATA": SearchResponse, "UUID": UserData._id });
    return;
}
async function StartFunc() {
    await Search();
}
StartFunc();
