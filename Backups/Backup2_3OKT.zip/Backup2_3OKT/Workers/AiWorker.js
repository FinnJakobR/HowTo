"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const OpenAi_1 = require("../AI/OpenAi");
const DataApi_1 = require("../Api/DataApi");
async function CreateNewQuestion() {
    const Data = await (0, DataApi_1.DequeueOpApi)("ai");
    const isConnected = await (0, DataApi_1.IsUserConnectedApi)(Data._ID);
    if (!isConnected) {
        process.send({ _id: Data._ID, detail: "User is disconnected" });
        return;
    }
    ;
    const newQuestion = await (0, OpenAi_1.GenerateNewWord)(Data.QUESTION);
    const API_Queue_Element = { _ID: Data._ID, URL: null, QUESTION: newQuestion };
    process.send({ _ID: Data._ID, newQuestion: newQuestion, detail: "AI_WORKER_ENDED" });
    await (0, DataApi_1.EnqueueOpApi)("api", API_Queue_Element);
    return;
}
CreateNewQuestion();
