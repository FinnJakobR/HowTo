"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const cors_1 = __importDefault(require("cors"));
const DataApi_1 = require("../Api/DataApi");
const FileOP_1 = require("../FileOperations/FileOP");
const Settings_1 = require("../Settings/Settings");
const StreamServer = (0, express_1.default)();
const PORT = Settings_1.StreamServerStettings.port;
StreamServer.use((0, cors_1.default)());
StreamServer.get(Settings_1.StreamServerStettings.url, async (req, res) => {
    const _id = req.params.id;
    const videos = req.params.video;
    const FileName = req.params.file;
    if (FileName == "index.m3u8")
        return res.status(200).sendFile(path_1.default.join(__dirname, `../${Settings_1.GeneralSettings.VideoDirName}`, `/${_id}`, "/index.m3u8"));
    const isAllreadySended = await (0, DataApi_1.IsAllreadyRequestedApi)(_id, `${videos}/${FileName}`);
    if (isAllreadySended)
        return res.status(200).sendFile(path_1.default.join(`${__dirname}`, `../${Settings_1.GeneralSettings.VideoDirName}`, `/${_id}`, `/${videos}`, `/${FileName}`));
    const FileNumber = FileName.match(/\d+/g);
    console.log("FileNumber: " + FileNumber[0]);
    const IndexLength = await (0, DataApi_1.GetIndexLengthApi)(_id, Number(videos)) / 1000; // Conert back to seconds !
    console.log("IndexLength of Video " + Number(videos) + " " + IndexLength);
    if (Number(FileNumber[0]) == IndexLength) {
        await (0, FileOP_1.WriteInStreamFile)(`#EXT-X-DISCONTINUITY\n#EXTINF:1.000000\n${Settings_1.GeneralSettings.HostName}:${Settings_1.StreamServerStettings.port}/${_id}/${Number(videos) + 1}/0.ts\n`, _id);
        return res.status(200).sendFile(path_1.default.join(`${__dirname}`, `../${Settings_1.GeneralSettings.VideoDirName}`, `/${_id}`, `/${videos}`, `/${FileName}`));
    }
    await (0, FileOP_1.WriteInStreamFile)(`#EXTINF:1.000000\n${Settings_1.GeneralSettings.HostName}:${Settings_1.StreamServerStettings.port}/${_id}/${videos}/${Number(FileNumber[0]) + 1}.ts\n`, _id);
    return res.status(200).sendFile(path_1.default.join(`${__dirname}`, `../${Settings_1.GeneralSettings.VideoDirName}`, `/${_id}`, `/${videos}`, `/${FileName}`));
});
StreamServer.listen(PORT, () => {
    console.log("STREAM SERVER STARTED");
});
