"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Settings_1 = require("../Settings/Settings");
const express_1 = __importDefault(require("express"));
const http_1 = __importDefault(require("http"));
const socket_io_1 = require("socket.io");
const cors_1 = __importDefault(require("cors"));
const FileOP_1 = require("../FileOperations/FileOP");
const worker_threads_1 = require("worker_threads");
const DataApi_1 = require("../Api/DataApi");
const child_process_1 = require("child_process");
const PORT = Settings_1.SocketServerSettings.port;
const ExpressMiddleware = (0, express_1.default)();
const server = http_1.default.createServer(ExpressMiddleware);
ExpressMiddleware.use((0, cors_1.default)());
const SocketServer = new socket_io_1.Server(server, {
    cors: {
        origin: "*"
    }
});
ExpressMiddleware.get("/", (req, res) => {
    res.sendFile(__dirname + "/Client.html");
});
SocketServer.on("connection", async (socket) => {
    console.log("A new User is Connected");
    socket.on(Settings_1.SocketServerSettings.NewVideoCommand, async (arg) => {
        console.log(arg);
        const QueueItem = { _ID: socket.id, URL: null, QUESTION: arg.value };
        await (0, DataApi_1.EnqueueOpApi)("api", QueueItem);
        const API = (0, child_process_1.fork)(Settings_1.GeneralSettings.path + "/Workers/ApiWorker.js");
        API.on("message", async (message) => {
            const stringMessage = JSON.stringify(message);
            const Message = JSON.parse(stringMessage);
            if (Message.MESSAGE == "USER IS DISCONNECTED!") {
                await (0, FileOP_1.DeleteUserDir)(Message.DATA.ID);
                return;
            }
            const VideoItem = {
                _ID: Message.DATA.ID,
                URL: Message.DATA.URL,
                QUESTION: arg.value
            };
            SocketServer.to(Message.UUID).emit(Settings_1.SocketServerSettings.SendTimeStampsCommand, { question: arg.value, TimeStamp: Message.DATA.DURATION });
            const VideoProcess = (0, child_process_1.fork)(Settings_1.GeneralSettings.path + "/Workers/DownloadWorker.js");
            VideoProcess.on("message", async (message) => {
                const StringMessage = JSON.stringify(message);
                const Message = JSON.parse(StringMessage);
                if (Message.detail == "First Segments are loaded" && arg.isFirstVideo) {
                    SocketServer.to(Message._id).emit(Settings_1.SocketServerSettings.StartClientPlayerCommand);
                }
                if (Message.detail == "User is disconnected") {
                    console.log("User " + Message._id + " is Disconected!");
                    return;
                }
                if (Message.detail == "DownLoadingConverting Finish") {
                    const AiItem = {
                        _ID: socket.id,
                        URL: null,
                        QUESTION: arg.value
                    };
                    await (0, DataApi_1.EnqueueOpApi)("ai", AiItem);
                    const AI = (0, child_process_1.fork)(Settings_1.GeneralSettings.path + "/Workers/AiWorker.js");
                    AI.on("message", (message) => {
                        const StringMessage = JSON.stringify(message);
                        const Message = JSON.parse(StringMessage);
                        SocketServer.to(Message._ID).emit(Settings_1.SocketServerSettings.CheckQuestCommand, { Question: Message.newQuestion, BeforeQuestion: arg.value });
                        return;
                    });
                }
                ;
            });
        });
    });
    await (0, DataApi_1.AddUserApi)(socket.id);
    await (0, FileOP_1.CreateUserDir)(socket.id);
    await (0, FileOP_1.CreateStreamingFile)(socket.id);
    if (!worker_threads_1.isMainThread)
        throw new Error("MainServer File have to on MainThread!");
    socket.on("disconnect", async () => {
        await (0, DataApi_1.RemoveUserApi)(socket.id);
        await (0, DataApi_1.DeleteUserFromQueueApi)(socket.id);
        console.log("DISCONNECT");
        setTimeout(async () => {
            await (0, FileOP_1.DeleteUserDir)(socket.id);
        }, 1000);
    });
});
server.listen(PORT, async () => {
    console.log("Pogramm sucessfull Started");
    console.log("Server Listen on port %d", PORT);
});
