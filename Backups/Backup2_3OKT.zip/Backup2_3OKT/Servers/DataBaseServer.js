"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const body_parser_1 = __importDefault(require("body-parser"));
const express_1 = __importDefault(require("express"));
const Dictonary_1 = require("../DataStructures/Dictonary");
const Queue_1 = require("../DataStructures/Queue");
const UserDictonary_1 = require("../DataStructures/UserDictonary");
const Settings_1 = require("../Settings/Settings");
// 1. Queue
const PORT = Settings_1.DataBaseServerSettings.port;
const DataBaseServer = (0, express_1.default)();
DataBaseServer.use(body_parser_1.default.json());
DataBaseServer.get("/QUEUE/:ID/DELETE_USER", (req, res) => {
    const _id = req.params.ID;
    (0, Queue_1.DeleteUserFromQueue)(_id);
    return res.status(200).send({ CODE: 200, MESSAGE: "Delte from Queue Operation sucessfull!", DATA: null });
});
DataBaseServer.get("/QUEUE/:QUEUE_TYPE/DEQUEUE/", (req, res) => {
    console.log("HELLO");
    const type = req.params.QUEUE_TYPE.toLowerCase();
    if (type.toLowerCase() != "ai" && type.toLowerCase() != "api" && type.toLowerCase() != "video") {
        res.send({ CODE: 404, MESSAGE: "Given Queue Name is not found" });
        return;
    }
    if (type == "api") {
        const Data = (0, Queue_1.DequeueApiQueue)();
        res.status(200).send({ CODE: 200, MESSAGE: "Queue operation sucess!", DATA: Data });
        return;
    }
    if (type == "ai") {
        const Data = (0, Queue_1.DequeueAIQueue)();
        res.status(200).send({ CODE: 200, MESSAGE: "Queue operation sucess!", DATA: Data });
        return;
    }
    if (type == "video") {
        const Data = (0, Queue_1.DequeueVideoQueue)();
        res.status(200).send({ CODE: 200, MESSAGE: "Queue operation sucess!", DATA: Data });
        return;
    }
});
DataBaseServer.post("/QUEUE/:QUEUE_TYPE/:OPERATION", (req, res) => {
    console.log(req.params.QUEUE_TYPE.toLowerCase());
    const type = req.params.QUEUE_TYPE.toLowerCase();
    const operation = req.params.OPERATION;
    const Body = req.body;
    console.log(operation);
    if (type.toLowerCase() != "ai" && type.toLowerCase() != "api" && type.toLowerCase() != "video") {
        res.send({ CODE: 404, MESSAGE: "Given Queue Name is not found" });
        return;
    }
    if (operation.toLowerCase() != "enqueue") {
        res.send({ CODE: 404, MESSAGE: "queue operation not Found for a get Request" });
        return;
    }
    console.log("ENQUEUE OPERATION");
    if (type == "ai") {
        (0, Queue_1.EnqueueInQueue)(Body);
        res.send({ CODE: 200, MESSAGE: "Queue operation sucess!", DATA: null });
        return;
    }
    if (type == "api") {
        console.log("HELLO");
        (0, Queue_1.EnqueueApiQueue)(Body);
        res.send({ CODE: 200, MESSAGE: "Queue operation sucess!", DATA: null });
        return;
    }
    if (type == "video") {
        (0, Queue_1.EnqueueVideoQueue)(Body);
        res.send({ CODE: 200, MESSAGE: "Queue operation sucess!", DATA: null });
        return;
    }
    throw Error("ERROR");
});
DataBaseServer.post("/DICTONARY/:OPERATION", (req, res) => {
    const operation = req.params.OPERATION.toLowerCase();
    const Body = req.body;
    if (operation != "saveprompt" && operation != "getprompt") {
        res.send({ CODE: 404, MESSAGE: "operation not Found!" });
        return;
    }
    if ((operation == "saveprompt" && !Body.generatedPrompt) || (operation == "saveprompt" && !Body.prompt)) {
        res.send({ CODE: 400, MESSAGE: "Body is not Valid!" });
        return;
    }
    if ((operation == "getprompt" && !Body.prompt)) {
        res.send({ CODE: 400, MESSAGE: "Body is not Valid!" });
        return;
    }
    if (operation == "saveprompt") {
        (0, Dictonary_1.SaveInDict)(Body.prompt, Body.generatedPrompt);
        res.send({ CODE: 200, MESSAGE: "Save Prompt sucess" });
        return;
    }
    if (operation == "getprompt") {
        const Data = (0, Dictonary_1.GetGeneratedPrompt)(Body.prompt);
        res.send({ CODE: 200, MESSAGE: "Get Prompt sucess", prompt: Data });
        return;
    }
});
DataBaseServer.post("/USERDATABASE/:USER_ID/:OPERATION", (req, res) => {
    const operation = req.params.OPERATION.toLowerCase();
    const Body = req.body;
    const _id = req.params.USER_ID;
    console.log("Operation: " + operation);
    if (operation != "changetimestamp" && operation != "getindexlength" && operation != "isallreadyrequested" && operation != "adduser" && operation != "addvideotouser" && operation != "isuserconnected" && operation != "removeuser" && operation != "getuserdata" && operation != "addfilestream" && operation != "getstream") {
        res.send({ CODE: 400, MESSAGE: "UserDatabase operation not found!" });
        return;
    }
    if (operation == "changetimestamp") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        console.log("SENDED TIMESTAMP: " + Body.newTimeStamp);
        (0, UserDictonary_1.ChangeTimeStamp)(_id, Body.newTimeStamp - 1000); //-1000 because of 0MS;
        res.send({ CODE: 200, MESSAGE: "Operation Sucess" });
        return;
    }
    if (operation == "getindexlength") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        const Data = (0, UserDictonary_1.GetIndexLength)(_id, Body.index);
        res.send({ CODE: 200, MESSAGE: "Operation Sucess", DATA: Data });
        return;
    }
    if (operation == "adduser") {
        (0, UserDictonary_1.ADD_User)(_id);
        res.send({ CODE: 200, MESSAGE: "User Added!" });
        return;
    }
    if (operation == "addvideotouser") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        (0, UserDictonary_1.AddVideoToUser)(_id);
        res.send({ CODE: 200, MESSAGE: "Operation Success" });
        return;
    }
    if (operation == "isallreadyrequested") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        const isReq = (0, UserDictonary_1.isAllreadyRequested)(_id, Body.FileName);
        res.send({ CODE: 200, MESSAGE: "Operation Success", ISREQ: isReq });
        return;
    }
    if (operation == "isuserconnected") {
        const isUserCon = (0, UserDictonary_1.IsUserConnected)(_id);
        res.send({ CODE: 200, MESSAGE: "Operation Success", ISUSERCON: isUserCon });
        return;
    }
    if (operation == "removeuser") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        (0, UserDictonary_1.RemoveUser)(_id);
        res.send({ CODE: 200, MESSAGE: "Operation Success" });
        return;
    }
    if (operation == "getuserdata") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        const Data = (0, UserDictonary_1.GETUserData)(_id);
        res.send({ CODE: 200, MESSAGE: "operation Success", DATA: Data });
        return;
    }
    if (operation == "addfilestream") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        (0, UserDictonary_1.AddFileStream)(_id);
        res.send({ CODE: 200, MESSAGE: "operation Success" });
        return;
    }
    if (operation == "getstream") {
        if (!(0, UserDictonary_1.IsUserConnected)(_id)) {
            return res.send({ CODE: 400, MESSAGE: "User is Disconnected" });
        }
        const stream = (0, UserDictonary_1.GetStream)(_id);
        res.send({ CODE: 200, MESSAGE: "operation Success", STREAM: stream });
        return;
    }
});
DataBaseServer.listen(PORT, () => {
    console.log("DataBaseServer started!");
});
