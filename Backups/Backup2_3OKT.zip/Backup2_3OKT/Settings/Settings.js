"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DictonarySettings = exports.StreamServerStettings = exports.SocketServerSettings = exports.OpenAiSettings = exports.GeneralSettings = exports.ApiSettings = exports.DataBaseServerSettings = void 0;
exports.DataBaseServerSettings = {
    port: 3000,
    hostname: "http://localhost"
};
exports.ApiSettings = {
    page: 1,
    safeSearch: true,
    type: "Video",
    resolution: "HD",
    sortBy: "Relevance",
    limit: 2
};
exports.GeneralSettings = {
    VideoDirName: "Videos",
    HostName: "http://localhost",
    path: ".",
};
exports.OpenAiSettings = {
    apikey: "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",
    model: "davinci:ft-universit-t-der-k-nste-berlin-2022-02-12-18-36-05",
    NumPerRun: 3,
    delayMs: 1000,
};
exports.SocketServerSettings = {
    port: 4000,
    NewVideoCommand: "NEW_VIDEO",
    SendTimeStampsCommand: "NEW_TIMESTAMP",
    StartClientPlayerCommand: "START_PLAYER",
    CheckQuestCommand: "CHECK_QUESTION"
};
exports.StreamServerStettings = {
    port: 1000,
    url: "/:id/:video/:file"
};
exports.DictonarySettings = {
    promptPath: "./Promps.txt"
};
